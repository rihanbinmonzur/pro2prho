<?php
include '../connection.php';
$data = [];

$query_type='';
$limit=" limit {$_GET['limit']}";

if($_GET['query_type']=='featured'){
	$query_type=" where is_featured=1";
}
else if($_GET['query_type']=='inspired'){
	$query_type=" where is_inspired=1";
}
else if($_GET['query_type']=='new_product'){
	$query_type=" order by id desc";
}

$sql = "SELECT products.*,brands.name as bname, categories.name as cat_name, colours.name as col_name FROM `products` 
JOIN categories on categories.id=products.category_id
JOIN brands on brands.id=products.brand_id
left JOIN colours on colours.id=products.colour_id $query_type $limit";
$result=$db->query($sql);
while($row = $result->fetch_object()){
	$data[]= $row;
}
echo json_encode($data); 